var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// data/datos.json
var require_datos = __commonJS({
  "data/datos.json"(exports2, module2) {
    module2.exports = {
      _info: "Fuente \xFAnica de datos de Patitaspe. Edita aqu\xED y corre: node scripts/sincronizar-datos.js",
      actualizado: "2026-10-21",
      servicios: [
        {
          id: "consulta",
          ic: "\u{1FA7A}",
          nm: "Consulta general",
          perro: {
            peq: [
              50,
              90
            ],
            med: [
              60,
              100
            ],
            gra: [
              70,
              110
            ]
          },
          gato: [
            50,
            90
          ]
        },
        {
          id: "vacunas",
          ic: "\u{1F489}",
          nm: "Vacunas (combo)",
          perro: {
            peq: [
              40,
              70
            ],
            med: [
              50,
              80
            ],
            gra: [
              60,
              90
            ]
          },
          gato: [
            40,
            70
          ]
        },
        {
          id: "despar",
          ic: "\u{1FAB1}",
          nm: "Desparasitaci\xF3n",
          perro: {
            peq: [
              20,
              40
            ],
            med: [
              25,
              45
            ],
            gra: [
              30,
              50
            ]
          },
          gato: [
            20,
            40
          ]
        },
        {
          id: "castra",
          ic: "\u2702\uFE0F",
          nm: "Castraci\xF3n (macho)",
          perro: {
            peq: [
              200,
              400
            ],
            med: [
              300,
              550
            ],
            gra: [
              400,
              650
            ]
          },
          gato: [
            180,
            350
          ]
        },
        {
          id: "esteril",
          ic: "\u2702\uFE0F",
          nm: "Esterilizaci\xF3n (hembra)",
          perro: {
            peq: [
              350,
              600
            ],
            med: [
              450,
              750
            ],
            gra: [
              600,
              950
            ]
          },
          gato: [
            300,
            550
          ]
        },
        {
          id: "sangre",
          ic: "\u{1FA78}",
          nm: "An\xE1lisis de sangre",
          perro: {
            peq: [
              80,
              150
            ],
            med: [
              90,
              160
            ],
            gra: [
              100,
              180
            ]
          },
          gato: [
            80,
            150
          ]
        },
        {
          id: "rayos",
          ic: "\u{1F9B4}",
          nm: "Radiograf\xEDa",
          perro: {
            peq: [
              80,
              130
            ],
            med: [
              90,
              150
            ],
            gra: [
              100,
              170
            ]
          },
          gato: [
            80,
            130
          ]
        },
        {
          id: "eco",
          ic: "\u{1F4E1}",
          nm: "Ecograf\xEDa abdominal",
          perro: {
            peq: [
              130,
              200
            ],
            med: [
              140,
              210
            ],
            gra: [
              150,
              230
            ]
          },
          gato: [
            130,
            200
          ]
        },
        {
          id: "hospi",
          ic: "\u{1F3E5}",
          nm: "Hospitalizaci\xF3n (1 noche)",
          perro: {
            peq: [
              120,
              250
            ],
            med: [
              150,
              300
            ],
            gra: [
              180,
              350
            ]
          },
          gato: [
            120,
            250
          ]
        },
        {
          id: "cirugia",
          ic: "\u2695\uFE0F",
          nm: "Cirug\xEDa general (media)",
          perro: {
            peq: [
              700,
              1500
            ],
            med: [
              900,
              1800
            ],
            gra: [
              1100,
              2200
            ]
          },
          gato: [
            700,
            1500
          ]
        },
        {
          id: "dental",
          ic: "\u{1F9B7}",
          nm: "Limpieza dental",
          perro: {
            peq: [
              150,
              300
            ],
            med: [
              180,
              350
            ],
            gra: [
              200,
              400
            ]
          },
          gato: [
            150,
            280
          ]
        },
        {
          id: "emerg",
          ic: "\u{1F6A8}",
          nm: "Recargo emergencia noche",
          perro: {
            peq: [
              50,
              100
            ],
            med: [
              60,
              120
            ],
            gra: [
              70,
              140
            ]
          },
          gato: [
            50,
            100
          ]
        }
      ],
      factor_zona: {
        norte: 0.85,
        sur: 0.85,
        centro: 1,
        este: 1
      },
      sintomas: [
        {
          id: "convul",
          t: "Convulsiones o temblores fuertes",
          lvl: "red"
        },
        {
          id: "respira",
          t: "Le cuesta respirar / respira agitado",
          lvl: "red"
        },
        {
          id: "encias",
          t: "Enc\xEDas p\xE1lidas, blancas o azuladas",
          lvl: "red"
        },
        {
          id: "orina",
          t: "No puede orinar o lo intenta sin lograrlo",
          lvl: "red"
        },
        {
          id: "sangre",
          t: "V\xF3mito o diarrea con sangre",
          lvl: "red"
        },
        {
          id: "toxico",
          t: "Comi\xF3 algo t\xF3xico (chocolate, veneno, xilitol)",
          lvl: "red"
        },
        {
          id: "barriga",
          t: "Barriga hinchada y dura / arcadas sin vomitar",
          lvl: "red"
        },
        {
          id: "golpe",
          t: "Lo atropellaron o sufri\xF3 un golpe fuerte o ca\xEDda",
          lvl: "red"
        },
        {
          id: "colapso",
          t: "Se desmay\xF3, colaps\xF3 o no se puede parar",
          lvl: "red"
        },
        {
          id: "sangrado",
          t: "Sangrado que no para",
          lvl: "red"
        },
        {
          id: "calor",
          t: "Jadeo extremo tras el calor / golpe de calor",
          lvl: "red"
        },
        {
          id: "vomito",
          t: "Vomit\xF3 2\u20133 veces, sin sangre",
          lvl: "amber"
        },
        {
          id: "nocome",
          t: "No quiere comer hace m\xE1s de 24 horas",
          lvl: "amber"
        },
        {
          id: "diarrea",
          t: "Diarrea sin sangre",
          lvl: "amber"
        },
        {
          id: "decaido",
          t: "Deca\xEDdo o durmiendo m\xE1s de lo normal",
          lvl: "amber"
        },
        {
          id: "cojea",
          t: "Cojea o le duele moverse",
          lvl: "amber"
        },
        {
          id: "agua",
          t: "Toma mucha m\xE1s agua u orina de m\xE1s, de golpe",
          lvl: "amber"
        }
      ],
      clinicas_24h: [
        {
          n: "Cl\xEDnica Veterinaria Gavet \u2014 Puente Piedra",
          z: "norte",
          dir: "Av. Puente Piedra 563, Puente Piedra",
          tel: "+51960814125",
          telDisp: "960 814 125",
          wa: "51960814125",
          maps: "Veterinaria Gavet, Av. Puente Piedra 563, Puente Piedra, Lima",
          conf: "Verificado en su web oficial"
        },
        {
          n: "Cl\xEDnica Veterinaria Gavet \u2014 Carabayllo",
          z: "norte",
          dir: "Estaci\xF3n Terminal Chimpu Ocllo (Metropolitano), Carabayllo",
          tel: "+51913728054",
          telDisp: "913 728 054",
          wa: "51913728054",
          maps: "Veterinaria Gavet Chimpu Ocllo, Carabayllo, Lima",
          conf: "Verificado en su web oficial"
        },
        {
          n: "DR.VET \u2014 Comas",
          z: "norte",
          dir: "Av. Universitaria Norte 7402, Urb. El Retablo, Comas (frente a EsSalud)",
          tel: "+5115377382",
          telDisp: "(01) 537 7382",
          wa: "",
          maps: "Av. Universitaria Norte 7402, Comas, Lima",
          conf: "Fuente: su blog oficial \u2014 confirma el tel\xE9fono"
        },
        {
          n: "Vetivet",
          z: "centro",
          dir: "Av. Aviaci\xF3n 3001, San Borja",
          tel: "+5117488000",
          telDisp: "(01) 748 8000",
          wa: "51984148981",
          maps: "Vetivet, Av. Aviaci\xF3n 3001, San Borja, Lima",
          conf: "Verificado en su web oficial"
        },
        {
          n: "Cl\xEDnica Veterinaria Rond\xF3n",
          z: "centro",
          dir: "Av. Pedro Venturo 104, Santiago de Surco",
          tel: "+5112084900",
          telDisp: "(01) 208 4900",
          wa: "51924679664",
          maps: "Veterinaria Rond\xF3n, Av. Pedro Venturo 104, Surco, Lima",
          conf: "Verificado en su web oficial"
        },
        {
          n: "Veterinaria Cavero",
          z: "centro",
          dir: "Av. Primavera 1780, Santiago de Surco",
          tel: "+5114355218",
          telDisp: "(01) 435 5218",
          wa: "",
          maps: "Veterinaria Cavero, Av. Primavera 1780, Surco, Lima",
          conf: "Verificado en su web oficial \xB7 especialistas en trauma y neuro"
        },
        {
          n: "Pet Time \u2014 Chorrillos",
          z: "sur",
          dir: "Av. Guardia Peruana 343, Chorrillos",
          tel: "+51993622898",
          telDisp: "993 622 898",
          wa: "51989979529",
          maps: "Pet Time Veterinaria Guardia Peruana, Chorrillos, Lima",
          conf: "Fuente: fichas y redes \u2014 confirma direcci\xF3n y tel\xE9fono"
        },
        {
          n: "Hospital Veterinario Maskoteka",
          z: "este",
          dir: "Av. Gran Chim\xFA 301, Z\xE1rate, San Juan de Lurigancho",
          tel: "+5114598694",
          telDisp: "(01) 459 8694",
          wa: "",
          maps: "Hospital Veterinario Maskoteka, Gran Chim\xFA, Z\xE1rate, SJL, Lima",
          conf: "Fuente: fichas y redes \u2014 confirma el tel\xE9fono"
        }
      ],
      distritos: {
        _nota: "Aproximaci\xF3n de qu\xE9 zona usa cada distrito para el factor de precio y el directorio 24h.",
        norte: [
          "Anc\xF3n",
          "Carabayllo",
          "Comas",
          "Independencia",
          "Los Olivos",
          "Puente Piedra",
          "San Mart\xEDn de Porres",
          "Santa Rosa"
        ],
        centro: [
          "Barranco",
          "Bre\xF1a",
          "Cercado de Lima",
          "Jes\xFAs Mar\xEDa",
          "La Victoria",
          "Lince",
          "Magdalena del Mar",
          "Miraflores",
          "Pueblo Libre",
          "R\xEDmac",
          "San Borja",
          "San Isidro",
          "San Miguel",
          "Santiago de Surco",
          "Surquillo"
        ],
        sur: [
          "Chorrillos",
          "Lur\xEDn",
          "Pachac\xE1mac",
          "Punta Hermosa",
          "San Bartolo",
          "San Juan de Miraflores",
          "Villa El Salvador",
          "Villa Mar\xEDa del Triunfo"
        ],
        este: [
          "Ate",
          "Chaclacayo",
          "Cieneguilla",
          "El Agustino",
          "La Molina",
          "Lurigancho-Chosica",
          "San Juan de Lurigancho",
          "San Luis",
          "Santa Anita"
        ]
      }
    };
  }
});

// netlify/lib/patitas.js
var require_patitas = __commonJS({
  "netlify/lib/patitas.js"(exports2, module2) {
    var datos = require_datos();
    var ZONAS = { norte: "Lima Norte", centro: "Lima Centro", sur: "Lima Sur", este: "Lima Este" };
    var TAMANOS = { peq: "peque\xF1o", med: "mediano", gra: "grande" };
    function normalizar(t) {
      return String(t || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").trim();
    }
    function zonaDe({ zona, distrito }) {
      const z = normalizar(zona);
      if (ZONAS[z]) return z;
      for (const [k, v] of Object.entries(ZONAS)) if (normalizar(v) === z) return k;
      const d = normalizar(distrito || zona);
      if (d) {
        for (const k of Object.keys(ZONAS)) {
          if ((datos.distritos[k] || []).some((x) => normalizar(x) === d || normalizar(x).includes(d) && d.length > 3)) return k;
        }
      }
      return null;
    }
    function especieDe(e) {
      const x = normalizar(e);
      if (["gato", "gata", "gatos", "felino"].includes(x)) return "gato";
      if (["perro", "perra", "perros", "canino", ""].includes(x)) return "perro";
      return null;
    }
    function tamanoDe(t) {
      const x = normalizar(t);
      if (["peq", "pequeno", "pequena", "chico", "chica", "mini", "toy"].includes(x)) return "peq";
      if (["gra", "grande", "gigante"].includes(x)) return "gra";
      return "med";
    }
    function servicioDe(s) {
      const x = normalizar(s);
      if (!x) return null;
      const alias = {
        castracion: "castra",
        castrar: "castra",
        esterilizacion: "esteril",
        esterilizar: "esteril",
        vacuna: "vacunas",
        vacunacion: "vacunas",
        desparasitacion: "despar",
        desparasitar: "despar",
        radiografia: "rayos",
        placa: "rayos",
        ecografia: "eco",
        hospitalizacion: "hospi",
        operacion: "cirugia",
        cirugia: "cirugia",
        limpieza: "dental",
        dientes: "dental",
        emergencia: "emerg",
        analisis: "sangre",
        hemograma: "sangre"
      };
      const id = alias[x] || x;
      return datos.servicios.find((s2) => s2.id === id || normalizar(s2.nm).startsWith(x)) || null;
    }
    function rango(servicio, especie, tamano, zona) {
      const base = especie === "gato" ? servicio.gato : servicio.perro[tamano];
      const f = datos.factor_zona[zona];
      return [Math.round(base[0] * f), Math.round(base[1] * f)];
    }
    function error(mensaje, extra) {
      return { ok: false, error: mensaje, ...extra };
    }
    function opcionesServicios() {
      return datos.servicios.map((s) => ({ id: s.id, nombre: s.nm }));
    }
    function precio(q) {
      const especie = especieDe(q.especie);
      if (!especie) return error("Por ahora solo cubrimos perros y gatos.");
      const zona = zonaDe(q);
      if (!zona) return error("No reconozco la zona o distrito. Usa norte, centro, sur o este, o un distrito de Lima.", { zonas: ZONAS });
      const tamano = tamanoDe(q.tamano);
      const lista = q.servicio ? [servicioDe(q.servicio)] : datos.servicios;
      if (!lista[0]) return error("No reconozco ese servicio.", { servicios: opcionesServicios() });
      const items = lista.map((s) => {
        const [min, max] = rango(s, especie, tamano, zona);
        return { id: s.id, servicio: s.nm, min, max, moneda: "PEN" };
      });
      return {
        ok: true,
        especie,
        tamano: especie === "perro" ? TAMANOS[tamano] : null,
        zona: ZONAS[zona],
        items,
        nota: "Rangos de referencia de cl\xEDnicas privadas en Lima; no son el tarifario de una cl\xEDnica espec\xEDfica.",
        actualizado: datos.actualizado
      };
    }
    function verificar(q) {
      const p = precio({ ...q });
      if (!p.ok) return p;
      if (p.items.length !== 1) return error("Indica qu\xE9 servicio te cotizaron.", { servicios: opcionesServicios() });
      const monto = Number(q.monto);
      if (!monto || monto <= 0) return error("Indica el monto que te cotizaron, en soles.");
      const { min, max, servicio } = p.items[0];
      const exceso = Math.round((monto - max) / max * 100);
      let veredicto, detalle;
      if (monto < min) {
        veredicto = "buen_precio";
        detalle = "Por debajo del rango normal.";
      } else if (monto <= max) {
        veredicto = "precio_justo";
        detalle = "Dentro del rango normal.";
      } else if (monto <= Math.round(max * 1.25)) {
        veredicto = "en_el_limite";
        detalle = `Un ${exceso}% por encima del techo: pregunta qu\xE9 incluye antes de pagar.`;
      } else {
        veredicto = "caro";
        detalle = `Un ${exceso}% por encima del techo: pide el detalle por escrito y busca una segunda opini\xF3n.`;
      }
      return { ok: true, servicio, monto, rango: [min, max], zona: p.zona, veredicto, detalle };
    }
    function triaje(q) {
      const especie = especieDe(q.especie) || "perro";
      const pedidos = (Array.isArray(q.sintomas) ? q.sintomas : String(q.sintomas || "").split(",")).map((s) => normalizar(s)).filter(Boolean);
      if (!pedidos.length) {
        return error("Indica al menos un s\xEDntoma.", { sintomas: datos.sintomas.map((s) => ({ id: s.id, descripcion: s.t, nivel: s.lvl })) });
      }
      const encontrados = datos.sintomas.filter((s) => pedidos.includes(s.id) || pedidos.includes(normalizar(s.t)));
      const desconocidos = pedidos.filter((p) => !encontrados.some((s) => s.id === p || normalizar(s.t) === p));
      const rojos = encontrados.filter((s) => s.lvl === "red");
      const ambar = encontrados.filter((s) => s.lvl === "amber");
      const nivel = rojos.length ? "rojo" : ambar.length ? "ambar" : "verde";
      const acciones = {
        rojo: "Emergencia: llamar ahora a una cl\xEDnica 24h e ir de inmediato. No esperar a ma\xF1ana.",
        ambar: "No parece de vida o muerte, pero hay que llamar hoy al veterinario y vigilar de cerca.",
        verde: "Sin se\xF1ales de alarma marcadas. Vigilar las pr\xF3ximas horas; si aparece una se\xF1al roja, ir a emergencia."
      };
      let extra = "";
      if (especie === "gato" && encontrados.some((s) => s.id === "orina")) {
        extra = "En gatos machos, no poder orinar es de vida o muerte en pocas horas.";
      }
      return {
        ok: true,
        especie,
        nivel,
        accion: acciones[nivel],
        aviso_especial: extra || null,
        sintomas_rojos: rojos.map((s) => s.t),
        sintomas_ambar: ambar.map((s) => s.t),
        no_reconocidos: desconocidos,
        descargo: "Orientaci\xF3n general, no reemplaza la evaluaci\xF3n de un veterinario."
      };
    }
    function clinicas(q) {
      const zona = q.zona || q.distrito ? zonaDe(q) : null;
      if ((q.zona || q.distrito) && !zona) return error("No reconozco la zona o distrito.", { zonas: ZONAS });
      const lista = datos.clinicas_24h.filter((c) => !zona || c.z === zona).map((c) => ({ nombre: c.n, zona: ZONAS[c.z], direccion: c.dir, telefono: c.telDisp, whatsapp: c.wa || null, verificacion: c.conf || null }));
      return { ok: true, zona: zona ? ZONAS[zona] : "Toda Lima", clinicas: lista, nota: "Llama antes de ir para confirmar que atienden en ese momento." };
    }
    function servicios() {
      return { ok: true, servicios: opcionesServicios(), zonas: ZONAS, distritos: datos.distritos };
    }
    var RUTAS2 = { precio, verificar, triaje, clinicas, servicios };
    module2.exports = { RUTAS: RUTAS2, precio, verificar, triaje, clinicas, servicios };
  }
});

// netlify/functions/api.js
var { RUTAS } = require_patitas();
var CABECERAS = {
  "Content-Type": "application/json; charset=utf-8",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Cache-Control": "public, max-age=300"
};
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: CABECERAS, body: "" };
  const ruta = (event.path || "").split("/").filter(Boolean).pop();
  const fn = RUTAS[ruta];
  if (!fn) {
    return { statusCode: 404, headers: CABECERAS, body: JSON.stringify({ ok: false, error: "Ruta no encontrada", rutas: Object.keys(RUTAS) }) };
  }
  let q = { ...event.queryStringParameters || {} };
  if (event.httpMethod === "POST" && event.body) {
    try {
      q = { ...q, ...JSON.parse(event.body) };
    } catch (e) {
      return { statusCode: 400, headers: CABECERAS, body: JSON.stringify({ ok: false, error: "JSON inv\xE1lido" }) };
    }
  }
  const r = fn(q);
  return { statusCode: r.ok ? 200 : 400, headers: CABECERAS, body: JSON.stringify(r) };
};
